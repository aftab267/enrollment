@extends('layout')
@section('content')

mba


@endsection
